package com.atguigu.git;

/**
 * @author layne
 */
public class GItTest {
    public static void main(String[] args) {
        System.out.println("hello git!");
        System.out.println("hello git2!");
        System.out.println("hello git3!");
        System.out.println("hello git4!");
        System.out.println("master test!");
        System.out.println("hot-fix test!");
        System.out.println("push test!");
        System.out.println("pull test!");
        System.out.println("gitee test!");
        System.out.println("gitee test2!");
    }
}
